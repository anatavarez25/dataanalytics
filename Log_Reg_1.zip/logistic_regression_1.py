# Logistic Regression

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# Importing the dataset
dataset = pd.read_csv('Social_Network_Ads.csv')

#Data Mining
dataset.head()
dataset.describe()
print("Missings in the data:")
display(dataset.isnull().sum())

#Histogramas
dataset['Age'].plot.hist(title="EDAD",bins=10)
dataset['EstimatedSalary'].plot.hist(title="SALARIOESTIMADO",bins=10)

#Graficando variables
t = np.arange(0.0, train_Y.shape[0], 1)

def age_gd():
    plt.figure()
    sns.swarmplot(x='Gender', y='Age', data=dataset, palette='RdBu')
    #plt.xticks()
    plt.show()
    
age_gd()

def sal_gd():
    plt.figure()
    sns.swarmplot(x='Gender', y='EstimatedSalary', data=dataset, palette='RdBu')
    #plt.xticks()
    plt.show()
    
sal_gd()

#Buscando Outliers
def age_box():
    plt.figure()
    sns.boxplot(x='Gender', y='Age', data=dataset, palette='RdBu')
    #plt.xticks()
    plt.show()
    
age_box()

def gd_box():
    plt.figure()
    sns.boxplot(x='Gender', y='EstimatedSalary', data=dataset, palette='RdBu')
    #plt.xticks()
    plt.show()
    
gd_box()

#Declarando variables
X = dataset.iloc[:, 1:4].values
y = dataset.iloc[:, 4].values

# Arreglando la data vacia
from sklearn.impute import SimpleImputer

imp = SimpleImputer(missing_values = np.nan, strategy = 'mean')
imp.fit(X[:, 1:3])
X[:, 1:3] = imp.transform(X[:, 1:3])

'''
imp2 = SimpleImputer(missing_values = np.nan, strategy = 'median')'''


#Convertir variable sexo en variables dicotomicas(dummys)
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

#convierte cada uno en columnas y aisla efecto de variables
onehotencoder = OneHotEncoder()
X = np.column_stack([onehotencoder.fit_transform(X[:, 0].reshape(-1,1)).toarray(), X[:, 1:]])

#1 masc y 0 femenino
labelencoder_X = LabelEncoder()
X[:, 0] = labelencoder_X.fit_transform(X[:, 0])

#Convertir X a float
X = np.asarray(X, dtype=np.float)

# Dividiendo datos en Training set y Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Feature Scaling (Normalizacion)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train[:,1:3] = sc.fit_transform(X_train[:,1:3])
X_test[:,1:3] = sc.transform(X_test[:,1:3])

# Fitting/Ajuste de Regresion Logistica a Training set
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train, y_train)

# Predicciones de Test set 
y_pred = classifier.predict(X_test)

# Matriz de Confusion 
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

#Métricas
from sklearn.metrics import roc_auc_score, roc_curve, f1_score, accuracy_score
print("Accuracy Score:")
accuracy_score(y_test, y_pred)

print("F1 Score:")
f1_score(y_test, y_pred)

print("ROC-AUC Score:")
roc_auc_score(y_test, y_pred)
#roc_curve(y_test, y_pred)
 
#modelo optimo
import statsmodels.api as sm
X_train = np.asarray(X_train, dtype=np.float)
logit_model = sm.Logit(y_train,X_train)
result=logit_model.fit()
print(result.summary())

# Visualizando los resultados 
#plot
import seaborn as sns
sns.regplot(x='Age', y='Purchased', data=dataset, logistic=True)
sns.regplot(x='EstimatedSalary', y='Purchased', data=dataset, logistic=True)
#sns.regplot(x='Gender', y='Purchased', data=dataset, logistic=True)

#convirtiendo x_test en array

X_test = np.asarray(X_test, dtype=np.float)

#grafico 3d
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap
fig = plt.figure()
ax = fig.add_subplot(111, projection ='3d')
 
ax.scatter(X_test[:, 0], X_test[:, 1],X_test[:, 2],  c=y_pred, alpha=0.3, cmap=ListedColormap(['red','blue']))

ax.set_xlabel('Gender')
ax.set_ylabel('Age')
ax.set_zlabel('ESalary')
plt.show()